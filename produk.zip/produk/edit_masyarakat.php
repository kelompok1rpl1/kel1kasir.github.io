<!DOCTYPE html>
<html>
<head>
<title>Edit Data Produk</title>
<link rel="stylesheet" type="text/css" href="style3.css">
</head>
<body>
<?php
$id=$_GET['id'];
include "../koneksi.php";
$sql="select * from produk where ProdukID='$id'";
$result=mysqli_query($koneksi,$sql);
$data=mysqli_fetch_array($result);
?>
<form method="POST" action="update_masyarakat.php">
<h2>Edit Data Produk</h2>
<hr>
<table width="100%">
<tr>
<td>ProdukID</td>
<td><input type="hidden" name="ProdukID" value="<?=
$data['ProdukID'] ?>"><input type="text" name="ProdukID" value="<?=
$data['ProdukID'] ?>"></td>
</tr>
<tr>
<td>NamaProduk</td>
<td><input type="text" name="NamaProduk" value="<?=
$data['NamaProduk'] ?>"></td>
</tr>
<tr>
<td>Harga</td>
<td><input type="text" name="Harga" value="<?=
$data['Harga'] ?>"></td>
</tr>
<tr>
<td>Stok</td>
<td><input type="text" name="Stok" value="<?=
$data['Stok'] ?>"></td>
</tr>
</table>
<hr>
<p align="right">
<input type="submit" name="ubah" value="ubah"
class="simpan">
<a href="tampil_masyarakat.php" class="batal">Batal</a>
</p>
</form>
</body>
</html>