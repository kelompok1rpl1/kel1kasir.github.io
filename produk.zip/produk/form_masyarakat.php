<!DOCTYPE html>
<html>
<head>
<title>Input Data Produk</title>
<link rel="stylesheet" type="text/css" href="style2.css">
</head>
<body>
<form method="POST" action="simpan_masyarakat.php">
<h2>Input Data Produk</h2>
<hr>
<table width="100%">
<tr>
<td>NamaProduk</td>
<td><input type="text" name="NamaProduk"></td>
</tr>
<tr>
<td>Harga</td>
<td><input type="text" name="Harga"></td>
</tr>
<tr>
<td>Stok</td>
<td><input type="text" name="Stok"></td>
</tr>
</table>
<hr>
<p align="right">
<input type="submit" name="simpan" value="Simpan"
class="simpan">
<a href="tampil_petugas.php" class="batal">Batal</a>
</p>
</form>
</body>
</html>