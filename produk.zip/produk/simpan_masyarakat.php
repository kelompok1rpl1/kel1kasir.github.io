<?php
if(isset($_POST['simpan'])){
$NamaProduk=$_POST['NamaProduk'];
$Harga=$_POST['Harga'];
$Stok=$_POST['Stok'];
include "../koneksi.php";
$sqls="insert into produk (NamaProduk, Harga, Stok) values ('$NamaProduk','$Harga','$Stok')";
$simpan=mysqli_query($koneksi,$sqls);
if($simpan){
echo "<script>alert('Data Berhasil
Disimpan')</script>";
}else{
echo "<script>alert('Data Gagal Disimpan')</script>";
}
}
?>
<meta http-equiv="refresh" content="1;url=tampil_masyarakat.php">