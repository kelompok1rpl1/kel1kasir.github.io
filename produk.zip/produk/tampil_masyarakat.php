<html>
<head>
<meta name="vieport" content="width=device-width,
initial-scale=1.0">
<title>Daftar Produk</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<h2>Daftar Produk</h2>
<table width="800px" border="1" cellpadding="10px"
cellspacing="1px">
<thead>
<tr>
<th width="30px">No</th>
<th width="70px">ProdukID</th>
<th width="70px">NamaProduk</th>
<th width="100px">Harga</th>
<th width="70px">Stok</th>
<th width="120px">Aksi</th>
</tr>
</thead>
<tbody>
<?php
include "../koneksi.php";
$sql="select * from produk";
$result=mysqli_query($koneksi,$sql);
$no=1;
while($data=mysqli_fetch_array($result))
{
if($no%2==0){
echo "<tr class='genap'>";
}else{
echo "<tr class='ganjil'>";
}
?>
<td><?= $no ?>.</td>
<td align="center"><?= $data['ProdukID']
?></td>
<td><?= $data['NamaProduk'] ?></td>
<td><?= $data['Harga'] ?></td>
<td><?= $data['Stok'] ?></td>
<td align="center" width="80px">
<a href="edit_masyarakat.php?id=<?= $data['ProdukID']
?>" class="edit">Edit</a>
<a href="delete_masyarakat.php?id=<?=$data['ProdukID'] ?>" 
	onclick="return confirm('Apakah Anda Yakin data produk <?= $data['NamaProduk'] ?> akan dihapus?')" class="hapus">Del</a>
</td>
</tr>
<?php
$no++;
}
?>
</tbody>
<tfoot>
<tr>
<td colspan="6">
<!-- Untuk nomor Halaman -->
</td>
</tr>
</tfoot>
</table>
<br>
<a href="form_masyarakat.php" class="simpan">[+] Data Produk</a>
</body>
</html>