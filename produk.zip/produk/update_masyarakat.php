<?php
if(isset($_POST['ubah'])){
$ProdukID=$_POST['ProdukID'];
$NamaProduk=$_POST['NamaProduk'];
$Harga=$_POST['Harga'];
$Stok=$_POST['Stok'];
include "../koneksi.php";
$sqle="update produk set ProdukID='$ProdukID', NamaProduk='$NamaProduk', Harga='$Harga', Stok='$Stok'   where ProdukID='$ProdukID'";
$simpan=mysqli_query($koneksi,$sqle);
if($simpan){
echo "<script>alert('Data Berhasil Di
Edit')</script>";
}else{
echo "<script>alert('Data Gagal Di Edit')</script>";
}
}
?>
<meta http-equiv="refresh" content="1;url=tampil_masyarakat.php">